@php
use Illuminate\Support\Facades\Storage;
@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $product->name }} - Happy Paws</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-amber-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <i class="fas fa-paw text-amber-600 text-2xl mr-2"></i>
                        <span class="text-xl font-bold text-gray-900">Happy Paws</span>
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="/" class="text-amber-800 hover:text-amber-600 font-medium">Home</a>
                    <a href="#" class="text-amber-800 hover:text-amber-600 font-medium">About Us</a>
                    <a href="/products" class="text-amber-800 hover:text-amber-600 font-medium">Products</a>
                    <a href="/login" class="bg-amber-600 text-white px-4 py-2 rounded-md">Login</a>
                    <a href="/register" class="bg-amber-600 text-white px-4 py-2 rounded-md">Register</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Product Details -->
    <div class="max-w-7xl mx-auto px-4 py-8">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Product Image -->
            <div class="space-y-4">
                <div class="aspect-w-1 aspect-h-1">
                    <img src="{{ $product->image ? Storage::url($product->image) : 'https://via.placeholder.com/600x600/A0522D/FFFFFF?text=' . urlencode($product->name) }}" 
                         alt="{{ $product->name }}" 
                         class="w-full h-96 object-cover rounded-lg shadow-lg">
                </div>
            </div>

            <!-- Product Info -->
            <div class="space-y-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">{{ $product->name }}</h1>
                    <p class="text-lg text-gray-600 mb-4">{{ $product->brand->name ?? 'No Brand' }}</p>
                </div>

                <!-- Price -->
                <div class="border-t border-b border-amber-200 py-6">
                    <div class="flex items-center space-x-4">
                        <span class="text-4xl font-bold text-amber-600">${{ number_format($product->price, 2) }}</span>
                        <span class="text-lg text-gray-500 line-through">${{ number_format($product->price * 1.2, 2) }}</span>
                        <span class="bg-red-100 text-red-800 text-sm font-medium px-2.5 py-0.5 rounded-full">Save 20%</span>
                    </div>
                    <p class="text-sm text-gray-600 mt-2">Free shipping on orders over $50</p>
                </div>

                <!-- Description -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                    <p class="text-gray-600 leading-relaxed">{{ $product->description }}</p>
                </div>

                <!-- Quantity and Add to Cart -->
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Quantity</label>
                        <div class="flex items-center space-x-2">
                            <button class="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50">
                                <i class="fas fa-minus text-gray-600"></i>
                            </button>
                            <input type="number" value="1" min="1" max="10" 
                                   class="w-16 text-center border border-gray-300 rounded-lg py-2">
                            <button class="w-10 h-10 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50">
                                <i class="fas fa-plus text-gray-600"></i>
                            </button>
                        </div>
                    </div>

                    <div class="space-y-3">
                        <button onclick="showLoginModal()" 
                                class="w-full bg-amber-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-amber-700 transition duration-300 flex items-center justify-center">
                            <i class="fas fa-lock mr-2"></i>
                            Login to Add to Cart
                        </button>
                        <button onclick="showLoginModal()" 
                                class="w-full bg-gray-100 text-gray-700 py-3 px-6 rounded-lg font-semibold hover:bg-gray-200 transition duration-300 flex items-center justify-center">
                            <i class="fas fa-lock mr-2"></i>
                            Login to Add to Wishlist
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Login Modal -->
    <div id="loginModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white rounded-2xl p-8 max-w-sm mx-auto text-center relative">
            <button class="absolute top-4 right-4 text-gray-500 hover:text-gray-700" onclick="document.getElementById('loginModal').classList.add('hidden')">
                <i class="fas fa-times text-xl"></i>
            </button>
            <i class="fas fa-lock text-5xl text-amber-600 mb-4"></i>
            <h3 class="text-2xl font-bold text-gray-800 mb-4">Please Login to Proceed</h3>
            <p class="text-gray-600 mb-6">You need to be logged in to add items to your cart or wishlist.</p>
            <div class="flex flex-col space-y-4">
                <a href="{{ route('login') }}" class="bg-amber-600 text-white px-6 py-3 rounded-md text-lg font-semibold">
                    <i class="fas fa-sign-in-alt mr-2"></i> Login
                </a>
                <a href="{{ route('register') }}" class="bg-gray-200 text-gray-800 px-6 py-3 rounded-md text-lg font-semibold hover:bg-gray-300 transition duration-300">
                    <i class="fas fa-user-plus mr-2"></i> Register
                </a>
            </div>
        </div>
    </div>

    <script>
        function addToCart(productId) {
            const isLoggedIn = false; // Simplified for testing
            
            if (isLoggedIn) {
                alert('Product added to cart! (This is a demo)');
            } else {
                showLoginModal();
            }
        }

        function showLoginModal() {
            document.getElementById('loginModal').classList.remove('hidden');
            document.getElementById('loginModal').classList.add('flex');
        }

        // Close modal when clicking outside
        window.onclick = function(event) {
            const modal = document.getElementById('loginModal');
            if (event.target == modal) {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }
        }
    </script>
</body>
</html>

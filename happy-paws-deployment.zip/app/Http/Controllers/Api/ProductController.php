<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\MongoDBService;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;

class ProductController extends Controller
{
    protected $mongodbService;

    public function __construct(MongoDBService $mongodbService)
    {
        $this->mongodbService = $mongodbService;
    }

    /**
     * Get all products with filtering and pagination
     */
    public function index(Request $request): JsonResponse
    {
        $filters = $request->only([
            'search', 'brand_id', 'min_price', 'max_price', 
            'featured', 'per_page', 'page'
        ]);

        $result = $this->mongodbService->getProducts($filters);

        return response()->json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => $result['pagination'] ?? null,
        ]);
    }

    /**
     * Get a specific product by ID
     */
    public function show($id): JsonResponse
    {
        $result = $this->mongodbService->getProduct($id);

        if (!$result || !isset($result['data'])) {
            return response()->json([
                'success' => false,
                'message' => 'Product not found',
            ], 404);
        }

        return response()->json([
            'success' => true,
            'data' => $result['data'],
        ]);
    }

    /**
     * Search products
     */
    public function search(Request $request): JsonResponse
    {
        $query = $request->get('q', '');
        $filters = $request->only([
            'brand_id', 'min_price', 'max_price', 'featured', 'per_page'
        ]);

        $result = $this->mongodbService->searchProducts($query, $filters);

        return response()->json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => $result['pagination'] ?? null,
            'query' => $query,
        ]);
    }

    /**
     * Get featured products
     */
    public function featured(Request $request): JsonResponse
    {
        $filters = array_merge($request->only(['per_page']), ['featured' => true]);
        $result = $this->mongodbService->getProducts($filters);

        return response()->json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => $result['pagination'] ?? null,
        ]);
    }

    /**
     * Get products by brand
     */
    public function byBrand($brandId, Request $request): JsonResponse
    {
        $filters = array_merge($request->only(['per_page']), ['brand_id' => $brandId]);
        $result = $this->mongodbService->getProducts($filters);

        return response()->json([
            'success' => true,
            'data' => $result['data'],
            'pagination' => $result['pagination'] ?? null,
        ]);
    }
}